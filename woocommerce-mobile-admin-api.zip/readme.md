# Installation Instructions:

1. Download plugin from github by [link](https://github.com/pintawebware/woocomerce-mobile-admin/releases/download/2.0/woocommerce-mobile-admin-api.zip)

2. Enter admin panel on your site and go to “Plugins” -> “Add new”
![2 step](https://wordpressapp.pro/assets/images/en/1.jpg)

3. Press “Upload Plugin” and choose file on your computer
![3 step](https://wordpressapp.pro/assets/images/en/2.jpg)

4. Then press “Install now” button
![4 step](https://wordpressapp.pro/assets/images/en/3.jpg)

5. After installation process is finished press “Activate plugin”, and after that installation is complete.
![5 step](https://wordpressapp.pro/assets/images/en/1.jpg)

6. Congratulations, the installation of the plugin is completed.
You can download application for your smartphone using links below:
[iOS](https://itunes.apple.com/ua/app/woocommerce-mobile-admin/id1232236943?mt=8)
[Android](https://play.google.com/store/apps/details?id=com.pinta.woocommerce.woocommercemobileadmin)